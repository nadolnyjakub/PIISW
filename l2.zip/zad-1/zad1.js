let circleVal = document.getElementById('my-slider').value;
console.log(circleVal);
document.getElementById('my-circle').innerHTML = '260px';

function changedSize () {
    let sizeAfterChange = document.getElementById('my-slider').value + 'px';
    let circle = document.getElementById('my-circle');
    circle.innerHTML = sizeAfterChange;
    circle.style.width = sizeAfterChange;
    circle.style.height = sizeAfterChange;
    circle.style.lineHeight = sizeAfterChange;
}