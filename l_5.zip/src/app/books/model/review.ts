export interface Review {
    id: number;
    forBook: number;
    title: string;
    description: string;
    rate: number;
  }
  