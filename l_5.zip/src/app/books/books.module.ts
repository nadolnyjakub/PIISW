import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookListComponent } from './components/book-list/book-list.component';
import {HttpClientModule} from "@angular/common/http";
import {RouterModule} from "@angular/router";
import { BookDetailsComponent } from './components/book-details/book-details.component';
import { BookEditComponent } from './components/book-edit/book-edit.component';
import { BookEditFormComponent } from './components/book-edit/book-edit-form/book-edit-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReviewAddComponent } from './components/review-add/review-add.component';
import { ReviewListComponent } from './components/review-list/review-list.component';

@NgModule({
  declarations: [
    BookListComponent,
    BookDetailsComponent,
    BookEditComponent,
    BookEditFormComponent,
    ReviewAddComponent,
    ReviewListComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class BooksModule { }
