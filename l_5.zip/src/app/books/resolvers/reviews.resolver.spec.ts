import { TestBed } from '@angular/core/testing';

import { ReviewsResolver } from './reviews.resolver';
import {BooksService} from "../services/books.service";

describe('ReviewsResolver', () => {
  let resolver: ReviewsResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: BooksService, useValue: {} }
      ]
    });
    resolver = TestBed.inject(ReviewsResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
