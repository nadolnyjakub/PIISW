import { Injectable } from '@angular/core';
import {
  Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { Observable } from 'rxjs';
import { BooksService } from '../services/books.service';
import { Review } from '../model/review';

@Injectable({
  providedIn: 'root'
})
export class ReviewsResolver implements Resolve<Review[]> {

  constructor(private readonly booksService: BooksService) {
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Review[]> {
    return this.booksService.getReviews(route.params['id']);
  }
}
