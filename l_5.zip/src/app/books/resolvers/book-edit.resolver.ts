import { Injectable } from '@angular/core';
import { Book } from '../model/book';
import {   Resolve,
    RouterStateSnapshot,
    ActivatedRouteSnapshot } from '@angular/router';
import { BooksService } from '../services/books.service';
import { Observable } from 'rxjs';



@Injectable({providedIn: 'root'})
export class BookEditResolver implements Resolve<Book> {
    constructor(private readonly booksService: BooksService){

    }
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Book> {
        console.log(state);
        // return this.booksService.editBook(route.params['id'], book);
        return this.booksService.getBook(route.params['id']);
    }
}