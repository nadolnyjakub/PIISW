import { Component, OnInit } from '@angular/core';
import { Review } from '../../model/review';
import { Router } from '@angular/router';
import { BooksService } from '../../services/books.service';
import { Input } from '@angular/core';

@Component({
  selector: 'bs-review-add',
  templateUrl: './review-add.component.html',
  styleUrls: ['./review-add.component.scss']
})
export class ReviewAddComponent implements OnInit {

  review : Review;
  @Input() bookId: number;

  constructor(private router: Router, private booksService: BooksService) { }

  ngOnInit(): void {
    this.review = {
      id: Date.now(),
      forBook: this.bookId,
      rate: 3,
      title: '',
      description: ''
    }
  }

  onSubmit() {
    if (this.review.rate < 0 || this.review.rate > 5 || this.review.rate === null 
      || this.review.description.length === 0 || this.review.title.length === 0) {}
    else {
      this.booksService.addReview(this.review).subscribe().unsubscribe();
    }
  }

  goBack() {
    this.router.navigate(['/books']);
  }
}
