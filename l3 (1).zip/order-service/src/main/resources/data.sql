INSERT INTO Delivery (id, courier_Name, delivery_Status)
VALUES
(1, 'Jan', 'CREATED'),
(2, 'Bonifacy', 'CREATED');