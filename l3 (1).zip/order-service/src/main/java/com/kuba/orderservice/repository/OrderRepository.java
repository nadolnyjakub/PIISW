package com.kuba.orderservice.repository;

import com.kuba.orderservice.model.Orderr;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends CrudRepository<Orderr, Long> {

}
