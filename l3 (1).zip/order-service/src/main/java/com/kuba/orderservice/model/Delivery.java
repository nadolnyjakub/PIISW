package com.kuba.orderservice.model;

import javax.persistence.*;
import lombok.Data;

@Data
@Entity
public class Delivery {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String courierName;
    @Enumerated(EnumType.STRING)
    @Column(name = "deliveryStatus")
    private DeliveryStatus status;
}
