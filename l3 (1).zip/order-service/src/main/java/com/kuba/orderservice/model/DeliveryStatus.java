package com.kuba.orderservice.model;

import javax.persistence.Enumerated;


public enum DeliveryStatus {
    CREATED, PICKED_UP, DELIVERED
}
