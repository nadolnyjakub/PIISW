package com.kuba.orderservice.model;


import lombok.Data;


import java.math.BigDecimal;
import javax.persistence.*;
@Data
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String name;
    private BigDecimal price;
}
