package com.kuba.orderservice.model;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
public class Orderr {
    @Id
    private long id;
    private String customerName;
    @JoinColumn()
    @OneToMany
    private List<OrderItem> items;
    @JoinColumn
    @OneToOne
    private Delivery delivery;
}
