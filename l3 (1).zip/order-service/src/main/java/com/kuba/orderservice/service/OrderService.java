package com.kuba.orderservice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kuba.orderservice.model.DeliveryStatus;
import com.kuba.orderservice.model.Orderr;
import com.kuba.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    public List<Orderr> getOrders() {
        return (List<Orderr>) orderRepository.findAll();
    }

    public Orderr addOrder(Orderr order) throws Exception {
        Optional<Orderr> x = orderRepository.findById(order.getId());
        if (x.isPresent()) throw new Exception("Zamowienie o podanym id juz istnieje");
        Orderr newOrder = orderRepository.save(order);
        if (!newOrder.getDelivery().getCourierName().equals(order.getDelivery().getCourierName())) {
            orderRepository.delete(newOrder);
            throw new Exception("Nazwy kurierow niezgodne");
        }
        String newOrderString = "{ \"orderId\": "+newOrder.getId()+",\"customerName\": \""+newOrder.getCustomerName()+
                "\", \"courierName\": \""+newOrder.getDelivery().getCourierName()+"\", \"deliveryStatus\": \""+newOrder.getDelivery().getStatus()+
                "\", \"productNames\": \""+newOrder.getItems()+"\", \"totalPrice\": 10}";
        var client = HttpClient.newHttpClient();
        var request = HttpRequest.newBuilder(URI.create("http://localhost:8080/order-history/create"))
                .header("Content-type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(newOrderString))
                .build();
        var response = client.send(request, new JsonBodyHandler<>(APOD.class));
        System.out.println(response);
        return newOrder;
    }

    public Orderr updateDelivery(long orderId, DeliveryStatus status) throws Exception {
        Optional<Orderr> x = orderRepository.findById(orderId);
        if (x.isEmpty()) throw new Exception("Nie ma zamowienia o podanym id");
        x.get().getDelivery().setStatus(status);
        System.out.println(status);
        System.out.println("LMAO " + x.get().getDelivery());
        var client = HttpClient.newHttpClient();
        var request = HttpRequest.newBuilder(URI.create("http://localhost:8080/order-history/" + x.get().getId() +"/delivery-status/edit?status=" + status))
                .header("accept", "application/json")
                .POST(HttpRequest.BodyPublishers.noBody())
                .build();
        var response = client.send(request, new JsonBodyHandler<>(APOD.class));
        System.out.println(response);
        return orderRepository.save(x.get());
    }
}
