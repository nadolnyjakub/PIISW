package com.kuba.orderservice.controller;

import com.kuba.orderservice.model.DeliveryStatus;
import com.kuba.orderservice.model.Orderr;
import com.kuba.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.http.HttpClient;


@RestController()
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;
    @GetMapping()
    public ResponseEntity<Object> getOrders() {
        return new ResponseEntity<>(orderService.getOrders(), HttpStatus.OK);
    }

    @PostMapping(path = "/create")
    public ResponseEntity<Object> addOrder(@RequestBody Orderr order) {
        Orderr newOrder;
        System.out.println(order.getId() + " " + order.getDelivery());
        try {
            newOrder = orderService.addOrder(order);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
    }

    @PostMapping(value = "/{orderId}/delivery-status/update")
    public ResponseEntity<Object> updateDeliveryStatus(@PathVariable Long orderId, @RequestParam String status){
        DeliveryStatus deliveryStatus = DeliveryStatus.valueOf(status);
        Orderr newOrder;
        try {
            newOrder = orderService.updateDelivery(orderId, deliveryStatus);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
    }

}
