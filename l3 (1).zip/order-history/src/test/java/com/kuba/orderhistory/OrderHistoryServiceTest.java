package com.kuba.orderhistory;

public class OrderHistoryServiceTest {
}
