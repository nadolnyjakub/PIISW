package com.kuba.orderhistory.service;

import com.kuba.orderhistory.OrderHistory;
import com.kuba.orderhistory.controller.OrderHistoryController;
import com.kuba.orderhistory.repository.OrderHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class OrderHistoryService {
    List<String> deliveryStatusList = Arrays.asList("CREATED", "PICKED_UP", "DELIVERED");

    @Autowired
    private OrderHistoryRepository orderHistoryRepository;
    public List<OrderHistory> getAllOrders() {
        return (List<OrderHistory>) orderHistoryRepository.findAll();
    }

    public OrderHistory addOrderHistory(OrderHistory orderHistory) throws Exception {
        System.out.println(orderHistory.getDeliveryStatus());
        if (!deliveryStatusList.contains(orderHistory.getDeliveryStatus())) throw new Exception("zly status podany");
        Optional<OrderHistory> o = orderHistoryRepository.findById(orderHistory.getOrderId());
        if (o.isPresent()) throw new Exception("istnieje juz o takim id");
        return orderHistoryRepository.save(orderHistory);
    }

    public void updateOrderHistory(Long id, String status) throws Exception{
        if (!deliveryStatusList.contains(status)) throw new Exception("zly status podany");
        Optional<OrderHistory> o = orderHistoryRepository.findById(id);
        if (o.isEmpty()) throw new Exception("nie istnieje o takim id");
        o.get().setDeliveryStatus(status);
        orderHistoryRepository.save(o.get());
    }
}
