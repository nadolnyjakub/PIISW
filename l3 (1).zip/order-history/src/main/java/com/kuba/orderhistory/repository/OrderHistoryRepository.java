package com.kuba.orderhistory.repository;

import com.kuba.orderhistory.OrderHistory;
import org.springframework.data.repository.CrudRepository;

public interface OrderHistoryRepository extends CrudRepository<OrderHistory, Long> {
}
