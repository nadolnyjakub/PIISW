package com.kuba.orderhistory.controller;

import com.kuba.orderhistory.OrderHistory;
import com.kuba.orderhistory.OrderHistoryApplication;
import com.kuba.orderhistory.service.OrderHistoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/order-history")
public class OrderHistoryController {

    @Autowired
    private OrderHistoryService orderHistoryService;
    @GetMapping()
    @ApiOperation(value = "", tags = "order-history-api")
    public ResponseEntity<Object> getOrderHistory() {

        return new ResponseEntity<>(orderHistoryService.getAllOrders(), HttpStatus.OK);
    }
    @PostMapping("/create")
    @ApiOperation(value = "/create", tags = "order-history-controller")
    public ResponseEntity<Object> addOrderHistory(@RequestBody OrderHistory orderHistory) {
        OrderHistory newOrderHistory = null;
        System.out.println(orderHistory);
        try {
            newOrderHistory = orderHistoryService.addOrderHistory(orderHistory);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(newOrderHistory, HttpStatus.CREATED);
    }

    @PostMapping("/{orderHistoryId}/delivery-status/edit")
    @ApiOperation(value = "/{orderHistoryId}/delivery-status/edit", tags = "order-history-controller")
    public ResponseEntity<Object> addOrderHistory(@PathVariable Long orderHistoryId, @RequestParam String status) {
        try {
            orderHistoryService.updateOrderHistory(orderHistoryId, status);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("Zaktualizowano", HttpStatus.OK);
    }
}
