INSERT INTO Order_History (order_Id, customer_Name, courier_Name, delivery_Status, product_Names, total_Price)
VALUES
(0, 'Jerzy', 'Marian', 'CREATED', 'jajko, masło, baton', 14.25);