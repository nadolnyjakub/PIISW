package com.capgemini.jpa.tasks;

import com.capgemini.jpa.entities.Comment;
import com.capgemini.jpa.repositories.CommentRepository;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;


@DataJpaTest
class Task6Test {
    @Autowired
    CommentRepository commentRepository;
    //TODO: add some tests

    @Test
//    @Sql("data6.sql")
    void noCommentTest() {
        Optional<Comment> comment = commentRepository.findByFollowerUserId("0");


        assertThat(comment.isEmpty(), Matchers.is(true));
    }

    @Test
    void noFollowerTest() {
        Optional<Comment> comment = commentRepository.findByFollowerUserId("uhiuhiu");


        assertThat(comment.isEmpty(), Matchers.is(true));
    }



}
