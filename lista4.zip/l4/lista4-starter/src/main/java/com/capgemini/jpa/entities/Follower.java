package com.capgemini.jpa.entities;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class Follower {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String userId;

    private LocalDateTime subscriptionDate;

    public Follower() {
        this.subscriptionDate = LocalDateTime.now();
    }
}
