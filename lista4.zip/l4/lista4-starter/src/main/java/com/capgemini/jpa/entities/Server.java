package com.capgemini.jpa.entities;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@SQLDelete(sql = "UPDATE Server SET is_active = false WHERE id=?")
@Where(clause = "is_active = true")
public class Server {

    @Id
    @SequenceGenerator(name = "SERVER_ID_GENERATOR", sequenceName = "SERVER_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SERVER_ID_GENERATOR")
    private Integer id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String ip;

    @Column()
    private LocalDateTime createdDate;

    @Column()
    private LocalDateTime lastUpdateDate;

    @Column
    private Boolean isActive = Boolean.TRUE;

    @Version
    private Long version;

    public Server(String name, String ip) {
        super();
        this.name = name;
        this.ip = ip;
    }

    @PrePersist
    public void prePersist() {
        this.createdDate = LocalDateTime.now();
        this.lastUpdateDate = LocalDateTime.of(this.createdDate.toLocalDate(), this.createdDate.toLocalTime());
    }

    @PreUpdate
    public void preUpdate() {
        this.lastUpdateDate = LocalDateTime.now();
    }

    public Long getVersion(){
        return version;
    }

    public LocalDateTime getCreatedDate(){
        return createdDate;
    }

    public LocalDateTime getLastUpdateDate(){
        return lastUpdateDate;
    }

}
