package com.capgemini.jpa.entities;

public enum HttpMethod {
    GET, PUT, DELETE, POST;
}
