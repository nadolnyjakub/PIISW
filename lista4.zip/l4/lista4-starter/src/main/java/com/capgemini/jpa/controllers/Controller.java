package com.capgemini.jpa.controllers;

import com.capgemini.jpa.entities.Comment;
import com.capgemini.jpa.entities.Server;
import com.capgemini.jpa.repositories.CommentRepository;
import com.capgemini.jpa.repositories.EventRepository;
import com.capgemini.jpa.repositories.ServerRepository;
import com.capgemini.jpa.repositories.ServerStatistic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController()
public class Controller {
    @Autowired
    EventRepository eventRepository;
    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ServerRepository serverRepository;
    @GetMapping("/xd")
    @Transactional
    public ResponseEntity<Object> test() {
//        eventRepository.deleteByTimeLessThan(LocalDateTime.now());          dziala ale transactional
//        List<ServerStatistic> l = eventRepository.findAllServerStatistics();
//        System.out.println(serverRepository.findById(1));
//        List<Server> servers = serverRepository.findAll();
//        System.out.println(servers.size());
//        for(Server s : servers) System.out.println(s);
//        System.out.println(l.size());
//        for (ServerStatistic serverStatistic : l) {
//            System.out.println(serverStatistic);
//        }
        Optional<Comment> com = commentRepository.findById(1L);
        Comment c = com.get();
        System.out.println(c.getEvents() + " " + c.getFollower() + " " + c.getContent());
        return null;
    }
}
