package com.capgemini.jpa.repositories;

import com.capgemini.jpa.entities.Server;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ServerRepository extends JpaRepository<Server, Integer> {

    Optional<Server> findByName(String name);
}
