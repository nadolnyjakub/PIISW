package com.capgemini.jpa.repositories;

import com.capgemini.jpa.entities.Event;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {
    Page<Event> findByTimeBetweenAndAnalysisRequired(LocalDateTime start, LocalDateTime end, boolean toBeAnalyzed, Pageable page);

    void deleteByTimeLessThan(LocalDateTime time);

    @Query("UPDATE Event e SET e.analysisRequired = true WHERE type(e) = :clazz AND e.duration > :minDuration")
    @Modifying
    void updateEvents(@Param("clazz") Class<? extends Event> clazz, @Param("minDuration") int minDuration);

    @Query("SELECT NEW com.capgemini.jpa.repositories.ServerStatistic(s, count(e.server)) FROM Event e JOIN e.server s GROUP BY s")
    List<ServerStatistic> findAllServerStatistics();
}
