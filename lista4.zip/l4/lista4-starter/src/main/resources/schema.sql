drop table if exists exception_event CASCADE;
drop table if exists request_event CASCADE;
drop table if exists server CASCADE;
drop table if exists sql_event CASCADE;
drop table if exists follower CASCADE;
drop table if exists comment CASCADE;
drop sequence if exists event_seq;
drop sequence if exists server_seq;
create sequence event_seq start with 1 increment by 1;
create sequence server_seq start with 1 increment by 1;
create table exception_event
(
    id                integer   not null,
    analysis_required boolean,
    duration          integer   not null,
    thread_id         varchar(10),
    time              timestamp not null,
    user_id           varchar(30),
    server_id         long   not null,
    comment_id        integer,
    exception_name    varchar(255),
    occurance_class   varchar(255),
    occurance_line    integer,
    occurance_method  varchar(255),
    primary key (id)
);
create table request_event
(
    id                integer      not null,
    analysis_required boolean,
    duration          integer      not null,
    thread_id         varchar(10),
    time              timestamp    not null,
    user_id           varchar(30),
    server_id         long      not null,
    comment_id        integer,
    method            varchar(255) not null,
    primary key (id)
);
create table server
(
    id               long      not null,
    ip               varchar(255) not null,
    last_update_date timestamp,
    created_date timestamp,
    is_active boolean,
    name             varchar(255) not null,
    version          bigint,
    primary key (id)
);
create table sql_event
(
    id                integer       not null,
    analysis_required boolean,
    duration          integer       not null,
    thread_id         varchar(10),
    time              timestamp     not null,
    user_id           varchar(30),
    server_id         long       not null,
    comment_id integer,
    sql_query         varchar(4000) not null,
    primary key (id)
);
create table follower
(
    user_id                varchar(1000)       not null,
    subscription_date timestamp,
    primary key (user_id)
);
create table comment
(
    id                integer       not null,
    content           varchar(4000) not null,
    follower_id       varchar(1000),
    primary key(id)
);
alter table exception_event
    add constraint FK_exc_ev_server foreign key (server_id) references server;
alter table exception_event
    add constraint FK_exc_event foreign key (comment_id) references comment;
alter table request_event
    add constraint FK_req_ev_event foreign key (server_id) references server;
alter table request_event
    add constraint FK_req_event foreign key (comment_id) references comment;
alter table sql_event
    add constraint FK__sql_ev_server foreign key (server_id) references server;
alter table comment
    add constraint FK_comment_follower foreign key (follower_id) references follower;

