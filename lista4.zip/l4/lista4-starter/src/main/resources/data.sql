insert into server(version, ip, name, id, created_date, last_update_date, is_active) values(1, '111.112.113.114', 'A',1, PARSEDATETIME('2018-02-03 03:18:06', 'yyyy-MM-dd HH:mm:ss'), PARSEDATETIME('2018-02-03 03:18:06', 'yyyy-MM-dd HH:mm:ss'), true);

insert into follower(user_id, subscription_date) values ('1', PARSEDATETIME('2018-02-03 03:18:06', 'yyyy-MM-dd HH:mm:ss'));
insert into follower(user_id, subscription_date) values ('2', PARSEDATETIME('2018-02-03 03:18:06', 'yyyy-MM-dd HH:mm:ss'));
insert into comment(id, content, follower_id) values (1, 'lol', '1');
insert into comment(id, content, follower_id) values (2, 'bezbek', '1');
insert into request_event(analysis_required, duration, server_id, thread_id, time, user_id, id, method, comment_id) values (false, 30, 	1, '2', 	PARSEDATETIME('2018-02-03 03:18:06', 'yyyy-MM-dd HH:mm:ss'), 'Adam', 	1	, 'PUT', 1);
insert into request_event(analysis_required, duration, server_id, thread_id, time, user_id, id, method, comment_id) values (false, 550, 	1, '3', 	PARSEDATETIME('2018-02-03 13:08:06', 'yyyy-MM-dd HH:mm:ss'), 'Adam', 	2	, 'PUT', 1);
insert into sql_event(analysis_required, duration, server_id, thread_id, time, user_id, id, sql_query, comment_id) values (false, 30, 		1, '2', 	PARSEDATETIME('2018-02-03 03:18:06', 'yyyy-MM-dd HH:mm:ss'), 'Adam', 	21,    'SELECT 1 FROM DUAL', 1);
insert into sql_event(analysis_required, duration, server_id, thread_id, time, user_id, id, sql_query, comment_id) values (false, 550, 		1, '3', 	PARSEDATETIME('2018-02-03 13:08:06', 'yyyy-MM-dd HH:mm:ss'), 'Adam', 	22,    'SELECT 1 FROM DUAL', 1);
commit;


alter sequence server_seq restart with 1000;
alter sequence event_seq restart with 1000;